import java.util.EmptyStackException;

public class Matcher {

	public MatchRtnCode matcher(String str) throws EmptyStackException {
		String temp = null;
		
		Stack<String> s1 = new LLStack<String>();
		
		String ret = "";
		
		String[] arr = str.split("");
		
		for (int i = 0; i < arr.length; i++) {
			//System.out.println("ok");
			if (arr[i].equals("{")) {
            	//System.out.println("Ok"+arr[i]);
            	s1.push(arr[i]);
            }
            else if (arr[i].equals("(")) {
            	//System.out.println("Ok" + arr[i]);
            	s1.push(arr[i]);
            }
            else if (arr[i].equals("[")) {
            	//System.out.println("Ok" + arr[i]);
            	s1.push(arr[i]);
            }
            else if (arr[i].equals("}")) {
            	try {
            	temp = s1.pop();
            	} catch (EmptyStackException e){
            		ret = "clos";
            	}
            	if (temp.equals("{")) {
            		//System.out.println("Sub}");
            	}
            	else {
            		//System.out.println(arr[i]);
            		ret = "unex";
            		break;
            	}
            }
            else if (arr[i].equals(")")) {
            	temp = s1.pop();
            	//System.out.println("This is " + temp);
            	if (temp.equals("(")) {
            		//System.out.println("Sub)");
            	}
            	else {
            		//System.out.println(arr[i]);
            		ret = "unex";
            		break;
            	}
            }
            else if (arr[i].equals("]")) {
            	temp = s1.pop();
            	if (temp.equals("[")) {
            		//System.out.println("Sub]");
            	}
            	else {
            		//System.out.println(arr[i]);
            		ret = "unex";
            		break;
            	}
            }
		}
		if (ret == "unex") {
        	return MatchRtnCode.UNEXPECTED_SYMBOL;
        }
        else if (ret == "clos") {
        	return MatchRtnCode.TOO_MANY_CLOSED_SYMBOLS;
        }
        else if (s1.isEmpty() != true) {
			ret = "open";
			return MatchRtnCode.TOO_MANY_OPEN_SYMBOLS;
		}
        else {
        	return MatchRtnCode.GOOD_STRING;
        }
		
		
	}
}
