import java.util.EmptyStackException;

// https://www.alphacodingskills.com/ds/notes/linked-list-delete-the-last-node.php#:~:text=Deleting%20the%20last%20node%20of,and%20delete%20the%20last%20node.
// https://gist.github.com/visparashar/eae5f848eca39788afdd2f79cd28580b
// https://www.geeksforgeeks.org/how-to-implement-generic-linkedlist-in-java/

public class LLStack<G> implements Stack<G>{
	
	class Node { // Nested protected Node class
		G data;
		Node next;

		Node(G data) {
			super();
			this.data = data;
			//this.next = null;
		}
		
		public Node getNext() {
			return next;
		}
		public void setNext(Node next) {
			this.next = next;
		}
		public G getData() {
			return data;
		}
	}

	Node head;
	Node tail;
	
	
	public void push(G data) {
		if (head == null) {
			head = new Node(data);
		} else {
			Node current = null;
			for (current = head; current.next != null; current = current.next) {
			}
			current.next = new Node(data);
		}
	}
	
	
	public G pop() throws EmptyStackException {
		G end = null;
		if (this.head != null) {
		    if (this.head.next == null) {
		    	end = this.head.getData();
		    	this.head = null;
		    } 
		    else {
		      Node temp = head;
		      temp = this.head;
		      while(temp.next.next != null)
		        temp = temp.next;
		     
		      end = temp.getNext().getData();
		      temp.next = null; 
		    }
		}
		else {
			throw new EmptyStackException();
		}
		return end;
		
	}
	
	public boolean isEmpty() {
		if (this.head == null) {
			System.out.println("Stack empty");
			return true;
		}
		else {
			System.out.println("Stack not empty");
			return false;
		}
		
	}

}
