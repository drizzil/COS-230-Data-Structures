import java.util.EmptyStackException;

public class ArrayStack<G> implements Stack<G> {

	
	
	G[] arr;
	int capacity;
	int push = 0;
	int len;
	G index;
	
	public ArrayStack() {
        super();
    }
	
	@SuppressWarnings("unchecked")
	public ArrayStack(int capacity) {
		arr = (G[]) new Object [capacity];
        this.capacity = capacity;
        len = arr.length;
    } 

	public void push(G data) throws FullStackException {
		if (push < capacity) {
			arr[push] = data;
			//System.out.println(arr[push]);
		}
		else {
			throw new FullStackException();
		}
		push++;
	}

	public G pop() throws EmptyStackException {
		if (len > 0) {
			index = arr[len - 1];
			arr[len - 1] = null;
			len--;
			return index;
		}
		else {
			throw new EmptyStackException();
		}
		
	}

	public boolean isEmpty() {
		return false;
	}

}
