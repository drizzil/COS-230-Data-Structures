import java.util.EmptyStackException;

public interface Stack<G> {
	void push(G data) throws FullStackException;
	G pop() throws EmptyStackException;
	boolean isEmpty();
}
